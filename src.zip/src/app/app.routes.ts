import { Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';
import { PlaceholderPageComponent } from './pages/placeholder-page/placeholder-page.component';

export const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      { path: '', component: PlaceholderPageComponent }
    ]
  }
];
