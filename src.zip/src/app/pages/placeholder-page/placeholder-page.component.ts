import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-placeholder-page',
  imports: [CommonModule],
  template: `
    <div style="padding:20px; background:#fff; border-radius:8px;">
      <h2>Hello, Angular 18 Shell Works 🎉</h2>
    </div>
  `
})
export class PlaceholderPageComponent {}
