import { Component } from '@angular/core';

@Component({
  selector: 'app-candidate-stub',
  standalone: true,
  imports: [],
  templateUrl: './candidate-stub.component.html',
  styleUrl: './candidate-stub.component.scss'
})
export class CandidateStubComponent {

}
