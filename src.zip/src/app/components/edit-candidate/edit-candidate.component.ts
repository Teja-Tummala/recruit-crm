import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-candidate',
  standalone: true,
  imports: [],
  templateUrl: './edit-candidate.component.html',
  styleUrl: './edit-candidate.component.scss'
})
export class EditCandidateComponent {

}
