import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CandidateApiService {

  constructor() { }
}
