import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

type Item = { icon: string; active?: boolean; title: string };

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent {
  top: Item[] = [
    { icon: 'bx-grid-alt', title: 'Dashboard' },
    { icon: 'bx-search', title: 'Search' },
    { icon: 'bx-user', title: 'Candidates', active: true },
    { icon: 'bx-briefcase', title: 'Jobs' },
    { icon: 'bx-envelope', title: 'Emails' },
    { icon: 'bx-calendar', title: 'Calendar' },
    { icon: 'bx-bar-chart', title: 'Reports' },
  ];

  bottom: Item[] = [
    { icon: 'bx-cog', title: 'Settings' },
    { icon: 'bx-help-circle', title: 'Help' },
  ];

   isExpanded = false; // toggle state

  toggleSidebar() {
    this.isExpanded = !this.isExpanded;
  }
}
